#include <stdio.h>
#include <ctype.h>
#include <string.h>

//####################################################  ESTRUTURAS  ###############################################################
typedef struct {
    char nome[50];
    int quantidade;
    float custo;
} Componente;

typedef struct {
    char nome[50];
    int ncomp; // permite dizer quantos componentes temos exatamente (dos 20 possíves, podemos não ter todos)
    Componente componentes[20]; //array chamado componentes, do tipo componente (no máximo pode ter 20 componentes)
} loja;

typedef struct {
    char nome[60];//o tamanho máximo do nome é de 60 carateres
    int idade;
    int contacto;
    char email[50]; //o tamanho máximo do e-mail é de 50 caracteres.
    char senha[10]; //o tamanho máximo da senha é de 10 caracteres.
} utilizador;

typedef struct {
    int indexloja;
    int indexcomponente;
} escolha; //estrutura para o carrinho de compras


//################################################## VARIAVEIS GLOBAIS ###############################################################
       
        #define Tamanho 4
        #define maxcarrinho 50 //numero maximo de componentes que podem ser adicionadas ao carrinho
        int nlojas=0; //variavel de inicialização, uma vez que posso ter até 5 lojas (mas podem não estar 5 lojas registadas)
        utilizador utilizadores[Tamanho]; //array 'utilizadores' contem numero 'Tamanho' de utilizadores. São do tipo utilizador.
        int nutilizador = 0; //variavel de inicialização para contar numero de utilizadores do sistema;
        escolha carrinho[maxcarrinho]; //array carrinho do tipo escolha, onde pode ter no máximo 50 componentes adicionados ao mesmo
        int itensCarrinho = 0; //numero de itens no carrinho

//################################################### FUNÇÕES DE VALIDAÇÃO ############################################################

/* Função para validar se a string contém apenas letras. */
            int validarLetras(const char* str) { 
                for (int i = 0; str[i] != '\0'; i++) //percorre cada carater da string até encontrar um carater nulo (fim da string)
                {  
                    if (!isalpha(str[i])) {
                        return 0; // Se encontrar um numero, a função retorna imediatamente 0.
                    }
                }
                return 1; // Se não encontrar números, a função retorna 1 (letras válidas).

            }

/* Função para validar se uma string contém apenas números.
--> 'const char*': um ponteiro para caracteres (char*), o 'const' indica que a função não modifica o conteúdo da string. Devolve um inteiro*/
            int validarNumeros(const char* str) {
                for (int i = 0; str[i] != '\0'; i++) {
                    if (!isdigit(str[i])) {
                        return 0; //Se encontrar uma letra, depois de ter percorrido a string, a função retorna '0'
                    }
                }
                return 1; //retorna '1' se tiver apenas numeros
            }

/* Função para validar se o email contem '@'*/
            int validarEmail(const char* str) {
                return strchr(str, '@') != NULL; // strchr -> função de C que procura por um carater especifico, neste caso '@'
            }
            // devolve 1 se encontrar o caractere '@' na string fornecida e retorna 0, caso não encontre


//############################################################ FUNÇÕES ###############################################################

void Inscricao(utilizador utilizadores[], int *nutilizador)
        /* ->Função que não retorna qualquer valor (void), chamada Inscrição. 
        -> Depois temos um array utilizadores do tipo utilizador. que nos permite aceder às informações da estrutura utilizador e guardar 
        novos utilizadores neste array. 
        -> Uso de um ponteiro(*) para que a função Inscricao possa modificar a variavel nutilizadores que está fora da função*/
    {
        if (*nutilizador >= Tamanho-1)
        {
            printf("::::::::::::::::::::::::::::::::\n O limite de utilizadores registados em sistema foi atingido! \n Por favor, contate o administrador do sistema!\n::::::::::::::::::::::::::::::::");
            return; // Sai da função
        }
        else
        {
            utilizador novoUtilizador;  //cria uma variavel 'novoUtilizador' do tipo 'utilizador'
            printf("Insira o seu nome: ");
            scanf_s("%s", novoUtilizador.nome);
            if (!validarLetras(novoUtilizador.nome)) /*Se a função 'validarLetras' retornar 0 (indicando que há algo no nome que não
            é uma letra), a negação ! tornará essa condição verdadeira. Isso significa que o código dentro do bloco if será executado */
            {
                printf("Nome invalido. Use apenas letras.\n");
                return;
            }
            printf("Insira a sua idade: ");
            scanf("%d", &novoUtilizador.idade);
            if (novoUtilizador.idade <= 0)
            {
                printf("Idade invalida. Insira um numero superior a zero.\n");
                return;
            }
            printf("Insira o seu contato: ");
            scanf("%d", &novoUtilizador.contacto); //lê o contato fornecido pelo user e o armazena na variável novoUtilizador.contacto.
            char strContato[20]; // será usada para armazenar a versão em string do número de contato.
            sprintf(strContato, "%d", novoUtilizador.contacto); //o valor de novoUtilizador.contacto é convertido em uma string que representa esse valor como um número inteiro e armazena em 'strContato'
            if (!validarNumeros(strContato)) //para depois de convertida ser usada aqui
            {
            printf("Numero de contacto invalido. Deve conter apenas numeros.\n");
            return;
            }
            printf("Insira o seu email: ");
            scanf_s("%s", novoUtilizador.email);
            if (!validarEmail(novoUtilizador.email))
            {
                printf("Email invalido. Deve conter '@'.\n");
                return;
            }
            printf("Insira a senha pretendida: ");
            scanf_s("%s", novoUtilizador.senha);
            printf("Volte a introduzir a sua senha: ");
            char confirmacaoSenha[10];
            scanf_s("%s", confirmacaoSenha);

            if (strcmp(novoUtilizador.senha, confirmacaoSenha) != 0) //a função 'strcmp' compara duas strings. Se elas forem iguais, devolve '0'
            {
                printf("A senha e a confirmacao de senha nao coincidem.\n");
                return;
            }

            (*nutilizador)++; // Atualiza o numero total de utilizadores
            utilizadores[*nutilizador-1] = novoUtilizador; //adiciona o novo utilizador ao array
            printf("Inscricao efetuada com sucesso!\n");
        }
    }

//####################################################  MAIN ###########################################################################
int main() {

int exit=0;
int ecra=0;
int opcao=0;
int sessaoiniciada = -1; // usei -1 para não interferir nos indices dos arrays que começam em zero. Quando inicia sessão, atualiza para o indicedo array do utilizador
loja lojas[5]; /* array 'lojas' contem 5 lojas. São do tipo loja. Cada uma das lojas tem os 'atributos' 
        que definimos na estrutura loja acima, incluindo um array 'Componentes' com 20 componentes.*/

//#################################################################  LOJAS E COMPONENTES  ##############################################
//1ª Loja
    strcpy(lojas[0].nome, "TecnoTopo"); 
    /*strcpy (destino, origem) => copiar informação de uma string para outra. 
    Esta função copia da origem para o destino.*/
    //primeiro componente
    lojas[0].componentes[0].custo=20.50; 
    strcpy(lojas[0].componentes[0].nome, "Rato sem fios - via bluetooth"); //nome 
    lojas[0].componentes[0].quantidade=10;
    //segundo componente 
    lojas[0].componentes[1].custo=50.00; 
    strcpy(lojas[0].componentes[1].nome, "Coluna sem fios"); 
    lojas[0].componentes[1].quantidade=8;
    //terceiro componente 
    lojas[0].componentes[2].custo=24.99; 
    strcpy(lojas[0].componentes[2].nome, "PowerBank - Carregador Portatil para telemovel"); 
    lojas[0].componentes[2].quantidade=4;
    //quarto componente 
    lojas[0].componentes[3].custo=12.99; 
    strcpy(lojas[0].componentes[3].nome, "Cabo Micro USB - 1,5m"); 
    lojas[0].componentes[3].quantidade=6;
    lojas[0].ncomp=4;
    nlojas++;   

//2ª Loja
    strcpy(lojas[1].nome, "Eletronicos Essenciais"); 
    //primeiro componente
    lojas[1].componentes[0].custo=89.95; 
    strcpy(lojas[1].componentes[0].nome, "Microondas Digital com Grill"); 
    lojas[1].componentes[0].quantidade=2;
    //segundo componente 
    lojas[1].componentes[1].custo=79.90; 
    strcpy(lojas[1].componentes[1].nome, "Torradeira 2 ranhuras - 'Daily Collection'"); 
    lojas[1].componentes[1].quantidade=6;
    //terceiro componente 
    lojas[1].componentes[2].custo=49.90; 
    strcpy(lojas[1].componentes[2].nome, "Maquina de cafe para capsulas e cafe moido"); 
    lojas[1].componentes[2].quantidade=4;
    //quarto componente 
    lojas[1].componentes[3].custo=97.50; 
    strcpy(lojas[1].componentes[3].nome, "Fritadeira de ar quente Airfryer - 5 litros"); 
    lojas[1].componentes[3].quantidade=7;
    lojas[1].ncomp=4;
    nlojas++;

//3ª Loja
    strcpy(lojas[2].nome, "iConnect Loja"); 
    //primeiro componente
    lojas[2].componentes[0].custo=1259.00; 
    strcpy(lojas[2].componentes[0].nome, "iPhone 13 Pro Max"); 
    lojas[2].componentes[0].quantidade=4;
    //segundo componente 
    lojas[2].componentes[1].custo=1050.90; 
    strcpy(lojas[2].componentes[1].nome, "iPhone 12 Pro Max"); 
    lojas[2].componentes[1].quantidade=3;
    //terceiro componente 
    lojas[2].componentes[2].custo=499.90; 
    strcpy(lojas[2].componentes[2].nome, "iPhone SE (2. geracao)"); 
    lojas[2].componentes[2].quantidade=4;
    //quarto componente 
    lojas[2].componentes[3].custo=689.50; 
    strcpy(lojas[2].componentes[3].nome, "iPhone 11"); 
    lojas[2].componentes[3].quantidade=2;
    //quinto componente 
    lojas[2].componentes[4].custo=709.50; 
    strcpy(lojas[2].componentes[4].nome, "iPhone XR"); 
    lojas[2].componentes[4].quantidade=1;
    //sexto componente 
    lojas[2].componentes[5].custo=1099.90; 
    strcpy(lojas[2].componentes[5].nome, "iPhone XS Max"); 
    lojas[2].componentes[5].quantidade=3;
    lojas[2].ncomp=6;
    nlojas++;



//#################################################################  UTILIZADORES  ##############################################
//Utilizador 1 -> Administrador
    strcpy(utilizadores[0].nome, "Administrador");
    utilizadores[0].idade = 25;
    utilizadores[0].contacto = 938262139;
    strcpy(utilizadores[0].email, "administrador@geral.pt");
    strcpy(utilizadores[0].senha, "senha123");
    nutilizador++; //sempre que adicionamos um novo utilizador, incrementamos 1. Ou seja, neste momento nutilizador=1


//#####################################################  MENU DE OPÇOES  ###################################################

 while(exit==0)
    {
            if(ecra==0)
            {
            printf("\n\n------------BEM VINDO AO GRUPO 'ELETRO-INTELIGENTE'-------------------\n\n");
            printf("Por favor selecione uma das seguintes opcoes:\n");
            printf("1-Registar-se\n");
            printf("2-Efetuar login\n");
            scanf("%d",&opcao);
            
                if (opcao==1){
                Inscricao(utilizadores, &nutilizador);}
            
                else if(opcao==2){
                ecra=2;
                char email[50];
                char senha[10];

                printf("Insira o seu email: ");
                scanf_s("%s", email, sizeof(email));
                printf("Insira a senha: ");
                scanf_s("%s", senha, sizeof(senha)); //'sizeof' para evitar possivel erro no programa
                /* Verificar se as credenciais correspondem a algum utilizador.
                Usamos a função 'strcmp' para comparar duas strings que compara os caracteres um a um,
                até encontrar um caractere diferente nas duas strings baseado no valor da tabela ASCII. 
                Se as strings forem iguais, a função retorna o valor 0. Pode retornar numeros positivos e negativos, 
                dependendo da relação lexicográfica (ordem que aparece no alfabeto) */
                for (int i = 0; i < nutilizador; i++) {
                if (strcmp(email, utilizadores[i].email) == 0 && strcmp(senha, utilizadores[i].senha) == 0) {
                printf("Login efetuado com sucesso!\n");
                sessaoiniciada = i;  // Armazena o índice do utilizador com sessão iniciada
                ecra = 1;  // Atualiza o valor de 'ecra' para 1
                break;  // Sai do loop após encontrar o utilizador
                }
                }

                if (sessaoiniciada == -1) {  // falha no início de sessão
                    if (strcmp(email, "administrador@geral.pt") == 0 && strcmp(senha, "senha123") == 0) {
                        printf("Login efetuado com sucesso como administrador!\n");
                        sessaoiniciada = 0;  // Atualiza o índice do administrador
                        ecra = 1;
                    } else {
                        printf("Credenciais invalidas. Tente novamente.\n");
                        ecra = 0;

                    }
                }
                }
            }
            

         else if (ecra==1) {  // Se a sessão estiver iniciada, o int sessaoiniciada = -1 vai corresponde ao índice do array
                    printf("\n -----------------MENU PRINCIPAL---------------------------\n");
                    printf("Por favor selecione uma das seguintes opcoes:\n\n");
                    printf("3-Pesquisar por loja\n");
                    printf("4-Pesquisar por componente\n");
                    printf("5-Confirmar carrinho\n");
                    printf("0-Sair\n");
                    scanf("%d", &opcao);


            if (opcao == 3) {
            printf("\n---------Lojas disponiveis:\n\n");
            for (int i = 0; i < nlojas; i++) { //percorre todas as lojas e mostra o indice e o seu nome
            printf("%d - %s\n\n", i, lojas[i].nome);
            }
            int escolhaLoja; //variavel que armazena a escolha do utilizador da loja pretendida
            printf("Escolha uma loja (insira o numero correspondente): ");
            scanf("%d", &escolhaLoja);

            if (escolhaLoja >= 0 && escolhaLoja < nlojas) {
            printf("Loja selecionada: %s\n", lojas[escolhaLoja].nome);
            printf("\n\n\nComponentes disponiveis na loja:\n");
            for (int j = 0; j < lojas[escolhaLoja].ncomp; j++) { //percorre e mostra todos os componentes da loja
            printf("%d - %s (Custo: %.2f, Restam apenas: %d unidades )\n\n\n",j, lojas[escolhaLoja].componentes[j].nome, 
                   lojas[escolhaLoja].componentes[j].custo, lojas[escolhaLoja].componentes[j].quantidade);
             }
            int escolhaComponente;
            printf("Escolha um componente para adicionar ao carrinho (insira o numero correspondente): ");
            scanf("%d", &escolhaComponente);
            /*  -> o proximo bloco if -> verifica se a escolha do componente é um nº maior ou igual a zero; 
            -> verifica se a escolha corresponde ao num. de componentes da loja
            -> verifica se existe unidades disponiveis do componente em stock*/
            if (escolhaComponente >= 0 && escolhaComponente < lojas[escolhaLoja].ncomp &&
            lojas[escolhaLoja].componentes[escolhaComponente].quantidade > 0) {

            carrinho[itensCarrinho].indexloja = escolhaLoja; //permite adicionar ao carrinho o nome da loja do componente selecionado
            carrinho[itensCarrinho].indexcomponente = escolhaComponente; //adiciona o componente ao carrinho
            itensCarrinho++; //atualiza o numero de itens no carrinho
            printf("\n Componente adicionado ao carrinho com sucesso!\n");
            } else {
            printf("\n O produto selecionado nao se encontra disponivel no momento!\n");
            }
            }
            } 



            else if (opcao == 4) {
            printf("\n-----------Lista de todos os componentes disponiveis em todas as lojas:\n\n");

            int totalComponentes = 0; //armazena numerar os componentes de todas as lojas e permitir o utilizador selecionar esse numero da lista
            for (int i = 0; i < nlojas; i++) { //loop para percorrer todas as lojas disponiveis

            for (int j = 0; j < lojas[i].ncomp; j++) { //percorre todos os componentes disponiveis em cada loja
            printf("%d - %s (Custo: %.2f, Restam: %d unidades)\n", totalComponentes, lojas[i].componentes[j].nome,
                   lojas[i].componentes[j].custo, lojas[i].componentes[j].quantidade); //imprime informações de cada componente, assim como o seu indice global ('totalComponentes')
            totalComponentes++; //incrementa a variavel 'totalComponentes' para atribuir um indice global do componente
            }
            }

            int escolhaComponente; //armazena a escolha do utilizador
            printf("\nEscolha um componente (insira o numero correspondente ao produto): ");
            scanf("%d", &escolhaComponente);

            if (escolhaComponente >= 0 && escolhaComponente < totalComponentes) { //verifica se o numero introduzido está dentro dos limites permitidos
                int lojaAtual = 0; //variavel que servirá para auxiliar na procura da loja correspondente
                while (escolhaComponente >= lojas[lojaAtual].ncomp) { //ciclo while -> enquanto a escolha do user for ao numero de componentes da loja atual 
                    escolhaComponente -= lojas[lojaAtual].ncomp; /*Exemplo: utilizador escreve o componente 15 e a loja onde esse componente está inserido tem apenas 10 comp. 
                    Após a execução deste excerto de codigo, a escolha será ajustada para 5, garantindo que esteja dentro dos limites válidos da loja atual (0 a 9, por exemplo).*/
                    lojaAtual++; //passa para a loja seguinte
                }

                carrinho[itensCarrinho].indexloja = lojaAtual; //índice da loja correspondente ao componente escolhido para carregar no carrinho
                carrinho[itensCarrinho].indexcomponente = escolhaComponente; //indice do componente escolhido para adicionar ao carrinho0
                itensCarrinho++; //indica que foi adicionado um novo item ao carrinho
                printf("\nComponente adicionado ao carrinho com sucesso!\n");
            } else {
                printf("\nEscolha inválida para o componente.\n");
            }
            }

        
        
        
        else if (opcao == 5) {
            if (itensCarrinho == 0) {
                printf("Carrinho vazio. Adicione itens antes de confirmar a compra.\n");
            } else {
                printf("Itens no carrinho:\n");   
                float totalCompra = 0.0; //armazena o total da compra
                for (int i = 0; i < itensCarrinho; i++) { //percorre todos os itens do carrinho
                    int indexLoja = carrinho[i].indexloja; //obtem indice da loja
                    int indexComponente = carrinho[i].indexcomponente; //obtem indice do componente
                    printf("%d - %s (Custo: %.2f)\n", i, lojas[indexLoja].componentes[indexComponente].nome,
                        lojas[indexLoja].componentes[indexComponente].custo);
                    totalCompra += lojas[indexLoja].componentes[indexComponente].custo; //soma todo o carrinho para apresentar o total
                }

                //confirmação do utilizador
                char confirmacao; 
                printf("Total: %.2f\n", totalCompra); 
                printf("Deseja confirmar a compra? (s/n) Ou digite 'L' para limpar o carrinho: ");
                scanf(" %c", &confirmacao);  
                if (confirmacao == 'L' || confirmacao == 'l') {
                itensCarrinho = 0;// Limpa o carrinho 
                printf("\nAcabamos de esvaziar o carrinho! Nao o deixe triste, acrescente itens!");}

                if (confirmacao == 's' || confirmacao == 'S') {
                    printf("Compra efetuada com sucesso! Total: %.2f\n", totalCompra);
                    itensCarrinho = 0;// Limpa o carrinho depois de efetuar a compra
                } else {
                    printf("\n\nClaro! Pode continuar a explorar as nossas lojas ... Vamos voltar ao menu principal....\n\n");
                }
            }
        }

             else if (opcao == 0) {
            exit = 1;  // Altera o valor de 'exit' para sair do loop
            }
        }
    }            
    



return 0;

}