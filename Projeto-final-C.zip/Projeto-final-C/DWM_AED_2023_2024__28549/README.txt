::::::::::::::::::::::::::::   BEM-VINDO AO SISTEMA DO GRUPO 'ELETRO-INTELIGENTE' ::::::::::::::::::::::::

Este é um projeto simples em linguagem C que simula um sistema de compras online para compra de componentes
eletrónicos e eletrodomésticos. 

Funcionalidades
  - Inscrever-se (Signup) & Entrar (Login) 
  - Pesquisa por loja 
  - Pesquisa por componente eletrónico 
  - Confirmação de carrinho e pedido 

...........................................................................................................
PARA COMEÇAR:

Para inciar o programa, por favor clique no atalho "Iniciar" no repositório. Também encontra  um 
poster-fluxograma (pasta: 'Poster-Fluxograma') para ajudar a perceber melhor o fluxo do sistema.  
Poderá explorar o código-fonte na pasta 'Ficheiro'. 

DISFRUTE!

Se tiver dúvidas, sugestões ou quer dar algum feedback, sinta-se à vontade para entrar em contato. Obrigado!
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::